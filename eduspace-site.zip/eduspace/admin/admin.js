// ===== EduSpace Admin JS =====

const DEFAULT_PASSWORD = 'eduspace2024';

// ── Auth ──
function getPassword() {
  return localStorage.getItem('eduspace_admin_pw') || DEFAULT_PASSWORD;
}
function doLogin() {
  const pw = document.getElementById('passwordInput').value;
  const err = document.getElementById('loginError');
  if (pw === getPassword()) {
    sessionStorage.setItem('eduspace_auth', '1');
    document.getElementById('loginScreen').style.display = 'none';
    document.getElementById('adminPanel').style.display = 'grid';
    initAdmin();
  } else {
    err.style.display = 'block';
    setTimeout(() => err.style.display = 'none', 2500);
  }
}
function doLogout() {
  sessionStorage.removeItem('eduspace_auth');
  document.getElementById('adminPanel').style.display = 'none';
  document.getElementById('loginScreen').style.display = 'flex';
  document.getElementById('passwordInput').value = '';
}
function changePassword() {
  const np = document.getElementById('newPassword').value;
  const cp = document.getElementById('confirmPassword').value;
  const msg = document.getElementById('pwMsg');
  if (!np) { showMsg(msg, 'შეიყვანეთ ახალი პაროლი', 'error'); return; }
  if (np !== cp) { showMsg(msg, 'პაროლები არ ემთხვევა', 'error'); return; }
  if (np.length < 6) { showMsg(msg, 'მინ. 6 სიმბოლო', 'error'); return; }
  localStorage.setItem('eduspace_admin_pw', np);
  document.getElementById('newPassword').value = '';
  document.getElementById('confirmPassword').value = '';
  showMsg(msg, '✓ პაროლი შეიცვალა', 'success');
}
function showMsg(el, text, type) {
  el.textContent = text;
  el.style.display = 'block';
  el.style.color = type === 'success' ? '#4ade80' : '#ff4d6d';
  setTimeout(() => el.style.display = 'none', 3000);
}

// ── Init ──
function initAdmin() {
  // Check if already logged in
  loadSettings();
  renderStats();
  renderPodcastsList();
  renderArticlesList();

  // Sidebar navigation
  document.querySelectorAll('.sidebar-link').forEach(btn => {
    btn.addEventListener('click', () => {
      switchTab(btn.dataset.tab);
    });
  });

  // Enter key on password
  document.getElementById('passwordInput')?.addEventListener('keydown', e => {
    if (e.key === 'Enter') doLogin();
  });
}

// Check session on load
window.addEventListener('DOMContentLoaded', () => {
  if (sessionStorage.getItem('eduspace_auth') === '1') {
    document.getElementById('loginScreen').style.display = 'none';
    document.getElementById('adminPanel').style.display = 'grid';
    initAdmin();
  }
  document.getElementById('passwordInput')?.addEventListener('keydown', e => {
    if (e.key === 'Enter') doLogin();
  });
  // Close modals on overlay click
  ['podcastModal','articleModal','confirmModal'].forEach(id => {
    document.getElementById(id)?.addEventListener('click', e => {
      if (e.target.id === id) document.getElementById(id).classList.remove('open');
    });
  });
  document.addEventListener('keydown', e => {
    if (e.key === 'Escape') {
      ['podcastModal','articleModal','confirmModal'].forEach(id =>
        document.getElementById(id)?.classList.remove('open'));
    }
  });
});

function switchTab(name) {
  document.querySelectorAll('.tab-content').forEach(t => t.classList.remove('active'));
  document.querySelectorAll('.sidebar-link').forEach(l => l.classList.remove('active'));
  document.getElementById('tab-' + name)?.classList.add('active');
  document.querySelector(`[data-tab="${name}"]`)?.classList.add('active');
  if (name === 'podcasts') renderPodcastsList();
  if (name === 'articles') renderArticlesList();
  if (name === 'dashboard') renderStats();
}

// ── Stats ──
function renderStats() {
  const podcasts = DB.getPodcasts();
  const articles = DB.getArticles();
  const el = document.getElementById('statsRow');
  if (!el) return;
  el.innerHTML = `
    <div class="stat-card">
      <span class="stat-num">${podcasts.length}</span>
      <div class="stat-label">პოდკასტი</div>
    </div>
    <div class="stat-card">
      <span class="stat-num">${articles.length}</span>
      <div class="stat-label">სტატია</div>
    </div>
    <div class="stat-card">
      <span class="stat-num">${podcasts.length + articles.length}</span>
      <div class="stat-label">სულ კონტენტი</div>
    </div>`;
}

// ── Podcasts ──
function renderPodcastsList() {
  const list = DB.getPodcasts();
  const el = document.getElementById('podcastsList');
  if (!el) return;
  if (!list.length) {
    el.innerHTML = '<div class="empty-state">პოდკასტები ჯერ არ დამატებულა<br/><small>დააჭირეთ "+ ახალი პოდკასტი"</small></div>';
    return;
  }
  el.innerHTML = list.map(p => {
    const ytId = getYouTubeId(p.url || '');
    const thumb = ytId ? getYouTubeThumbnail(ytId) : null;
    return `
      <div class="list-item">
        ${thumb
          ? `<img class="list-item-thumb" src="${thumb}" alt="thumb" loading="lazy"/>`
          : `<div class="list-item-thumb-placeholder">▶</div>`}
        <div class="list-item-info">
          <div class="list-item-title">${escHtml(p.title)}</div>
          <div class="list-item-meta">${formatDate(p.date)}${p.url ? ` · <a href="${escHtml(p.url)}" target="_blank" style="color:#4a9eff">YouTube ↗</a>` : ''}</div>
        </div>
        <div class="list-item-actions">
          <button class="btn btn-outline btn-icon" onclick="editPodcast('${p.id}')">✏️</button>
          <button class="btn btn-danger btn-icon" onclick="confirmDelete('podcast','${p.id}')">🗑</button>
        </div>
      </div>`;
  }).join('');
}

let _podcastEditId = null;
function openPodcastModal(id) {
  _podcastEditId = id || null;
  document.getElementById('podcastModalTitle').textContent = id ? 'პოდკასტის რედაქტირება' : 'ახალი პოდკასტი';
  document.getElementById('podcastTitle').value = '';
  document.getElementById('podcastUrl').value = '';
  document.getElementById('podcastDesc').value = '';
  document.getElementById('ytPreview').style.display = 'none';
  if (id) {
    const p = DB.getPodcasts().find(x => x.id === id);
    if (p) {
      document.getElementById('podcastTitle').value = p.title || '';
      document.getElementById('podcastUrl').value = p.url || '';
      document.getElementById('podcastDesc').value = p.description || '';
      previewYoutube();
    }
  }
  document.getElementById('podcastModal').classList.add('open');
}
function editPodcast(id) { openPodcastModal(id); }
function closePodcastModal() {
  document.getElementById('podcastModal').classList.remove('open');
  _podcastEditId = null;
}
function savePodcast() {
  const title = document.getElementById('podcastTitle').value.trim();
  const url = document.getElementById('podcastUrl').value.trim();
  if (!title) { showToast('სათაური სავალდებულოა', 'error'); return; }
  if (!url) { showToast('YouTube ლინკი სავალდებულოა', 'error'); return; }
  if (!getYouTubeId(url)) { showToast('არასწორი YouTube ლინკი', 'error'); return; }
  const data = {
    title,
    url,
    description: document.getElementById('podcastDesc').value.trim()
  };
  if (_podcastEditId) {
    DB.updatePodcast(_podcastEditId, data);
    showToast('✓ პოდკასტი განახლდა', 'success');
  } else {
    DB.addPodcast(data);
    showToast('✓ პოდკასტი დაემატა', 'success');
  }
  closePodcastModal();
  renderPodcastsList();
  renderStats();
}
function previewYoutube() {
  const url = document.getElementById('podcastUrl').value;
  const ytId = getYouTubeId(url);
  const preview = document.getElementById('ytPreview');
  if (ytId) {
    document.getElementById('ytThumb').src = getYouTubeThumbnail(ytId);
    preview.style.display = 'block';
  } else {
    preview.style.display = 'none';
  }
}

// ── Articles ──
function renderArticlesList() {
  const list = DB.getArticles();
  const el = document.getElementById('articlesList');
  if (!el) return;
  if (!list.length) {
    el.innerHTML = '<div class="empty-state">სტატიები ჯერ არ დამატებულა<br/><small>დააჭირეთ "+ ახალი სტატია"</small></div>';
    return;
  }
  el.innerHTML = list.map(a => `
    <div class="list-item">
      ${a.imageUrl
        ? `<img class="list-item-thumb" src="${a.imageUrl}" alt="cover" loading="lazy"/>`
        : `<div class="list-item-thumb-placeholder">📝</div>`}
      <div class="list-item-info">
        <div class="list-item-title">${escHtml(a.title)}</div>
        <div class="list-item-meta">${formatDate(a.date)}${a.tag ? ` · ${escHtml(a.tag)}` : ''}</div>
      </div>
      <div class="list-item-actions">
        <button class="btn btn-outline btn-icon" onclick="editArticle('${a.id}')">✏️</button>
        <button class="btn btn-danger btn-icon" onclick="confirmDelete('article','${a.id}')">🗑</button>
      </div>
    </div>`).join('');
}

let _articleEditId = null;
function openArticleModal(id) {
  _articleEditId = id || null;
  document.getElementById('articleModalTitle').textContent = id ? 'სტატიის რედაქტირება' : 'ახალი სტატია';
  document.getElementById('articleTitle').value = '';
  document.getElementById('articleTag').value = '';
  document.getElementById('articleExcerpt').value = '';
  document.getElementById('articleContent').value = '';
  document.getElementById('articleImageData').value = '';
  document.getElementById('articleImagePreviewWrap').style.display = 'none';
  document.getElementById('articleImageFile').value = '';
  if (id) {
    const a = DB.getArticles().find(x => x.id === id);
    if (a) {
      document.getElementById('articleTitle').value = a.title || '';
      document.getElementById('articleTag').value = a.tag || '';
      document.getElementById('articleExcerpt').value = a.excerpt || '';
      document.getElementById('articleContent').value = a.content || '';
      if (a.imageUrl) {
        document.getElementById('articleImageData').value = a.imageUrl;
        document.getElementById('articleImagePreview').src = a.imageUrl;
        document.getElementById('articleImagePreviewWrap').style.display = 'block';
      }
    }
  }
  document.getElementById('articleModal').classList.add('open');
}
function editArticle(id) { openArticleModal(id); }
function closeArticleModal() {
  document.getElementById('articleModal').classList.remove('open');
  _articleEditId = null;
}
async function handleArticleImage(event) {
  const file = event.target.files[0];
  if (!file) return;
  if (file.size > 3 * 1024 * 1024) {
    showToast('ფოტო ძალიან დიდია (მაქს. 3MB)', 'error');
    return;
  }
  const b64 = await fileToBase64(file);
  document.getElementById('articleImageData').value = b64;
  document.getElementById('articleImagePreview').src = b64;
  document.getElementById('articleImagePreviewWrap').style.display = 'block';
}
function clearArticleImage() {
  document.getElementById('articleImageData').value = '';
  document.getElementById('articleImagePreview').src = '';
  document.getElementById('articleImagePreviewWrap').style.display = 'none';
  document.getElementById('articleImageFile').value = '';
}
function saveArticle() {
  const title = document.getElementById('articleTitle').value.trim();
  const content = document.getElementById('articleContent').value.trim();
  if (!title) { showToast('სათაური სავალდებულოა', 'error'); return; }
  if (!content) { showToast('ტექსტი სავალდებულოა', 'error'); return; }
  const data = {
    title,
    tag: document.getElementById('articleTag').value.trim(),
    excerpt: document.getElementById('articleExcerpt').value.trim(),
    content,
    imageUrl: document.getElementById('articleImageData').value || ''
  };
  if (_articleEditId) {
    DB.updateArticle(_articleEditId, data);
    showToast('✓ სტატია განახლდა', 'success');
  } else {
    DB.addArticle(data);
    showToast('✓ სტატია დაემატა', 'success');
  }
  closeArticleModal();
  renderArticlesList();
  renderStats();
}

// ── Settings ──
function loadSettings() {
  const s = DB.getSettings();
  const nameEl = document.getElementById('settingName');
  const tagEl = document.getElementById('settingTagline');
  const aboutEl = document.getElementById('settingAbout');
  if (nameEl) nameEl.value = s.siteName || '';
  if (tagEl) tagEl.value = s.tagline || '';
  if (aboutEl) aboutEl.value = s.aboutText || '';

  if (s.logoUrl) {
    const prev = document.getElementById('logoPreview');
    const sl = document.getElementById('sidebarLogo');
    if (prev) { prev.src = s.logoUrl; prev.style.display = 'block'; }
    if (sl) sl.src = s.logoUrl;
  }
  if (s.coverUrl) {
    const cp = document.getElementById('coverPreview');
    const cn = document.getElementById('coverNoImg');
    if (cp) { cp.src = s.coverUrl; cp.style.display = 'block'; }
    if (cn) cn.style.display = 'none';
  }
}

async function handleLogoUpload(event) {
  const file = event.target.files[0];
  if (!file) return;
  if (file.size > 2 * 1024 * 1024) { showToast('ლოგო ძალიან დიდია (მაქს. 2MB)', 'error'); return; }
  const b64 = await fileToBase64(file);
  const s = DB.getSettings();
  s.logoUrl = b64;
  DB.saveSettings(s);
  document.getElementById('logoPreview').src = b64;
  document.getElementById('logoPreview').style.display = 'block';
  document.getElementById('sidebarLogo').src = b64;
  showToast('✓ ლოგო შეიცვალა', 'success');
}

async function handleCoverUpload(event) {
  const file = event.target.files[0];
  if (!file) return;
  if (file.size > 5 * 1024 * 1024) { showToast('ქავერი ძალიან დიდია (მაქს. 5MB)', 'error'); return; }
  const b64 = await fileToBase64(file);
  const s = DB.getSettings();
  s.coverUrl = b64;
  DB.saveSettings(s);
  const cp = document.getElementById('coverPreview');
  const cn = document.getElementById('coverNoImg');
  cp.src = b64; cp.style.display = 'block';
  if (cn) cn.style.display = 'none';
  showToast('✓ ქავერი შეიცვალა', 'success');
}

function removeCover() {
  const s = DB.getSettings();
  s.coverUrl = '';
  DB.saveSettings(s);
  const cp = document.getElementById('coverPreview');
  const cn = document.getElementById('coverNoImg');
  cp.src = ''; cp.style.display = 'none';
  if (cn) cn.style.display = 'block';
  showToast('ქავერი წაიშალა', 'success');
}

function saveSettings() {
  const s = DB.getSettings();
  s.siteName = document.getElementById('settingName').value.trim() || 'EduSpace';
  s.tagline = document.getElementById('settingTagline').value.trim() || 'Learn • Explore • Grow';
  s.aboutText = document.getElementById('settingAbout').value.trim();
  DB.saveSettings(s);
  showToast('✓ პარამეტრები შენახულია', 'success');
}

// ── Delete Confirm ──
let _deleteCallback = null;
function confirmDelete(type, id) {
  _deleteCallback = () => {
    if (type === 'podcast') { DB.deletePodcast(id); renderPodcastsList(); }
    if (type === 'article') { DB.deleteArticle(id); renderArticlesList(); }
    renderStats();
    showToast('წაიშალა', 'success');
    closeConfirm();
  };
  document.getElementById('confirmModal').classList.add('open');
  document.getElementById('confirmDeleteBtn').onclick = _deleteCallback;
}
function closeConfirm() {
  document.getElementById('confirmModal').classList.remove('open');
  _deleteCallback = null;
}

// ── Toast ──
function showToast(msg, type = '') {
  const t = document.getElementById('toast');
  t.textContent = msg;
  t.className = 'toast show ' + type;
  setTimeout(() => t.classList.remove('show'), 3000);
}

// ── Escape HTML (reuse from main.js if present) ──
if (typeof escHtml === 'undefined') {
  window.escHtml = function(str) {
    if (!str) return '';
    return String(str)
      .replace(/&/g, '&amp;')
      .replace(/</g, '&lt;')
      .replace(/>/g, '&gt;')
      .replace(/"/g, '&quot;');
  };
}
