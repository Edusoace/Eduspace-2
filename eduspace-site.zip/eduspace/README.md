# EduSpace — საიტის სტრუქტურა

> Learn • Explore • Grow

## 📁 ფაილების სტრუქტურა

```
eduspace/
├── index.html          ← მთავარი გვერდი
├── podcasts.html       ← პოდკასტების გვერდი
├── articles.html       ← სტატიების გვერდი
├── about.html          ← ჩვენ შესახებ
├── vercel.json         ← Vercel კონფიგურაცია
├── css/
│   └── style.css       ← მთავარი სტილები
├── js/
│   ├── data.js         ← მონაცემების მართვა (localStorage)
│   └── main.js         ← საიტის ლოგიკა
├── images/
│   └── logo.png        ← ▶ ჩასვით ლოგო აქ
└── admin/
    ├── index.html      ← ადმინ პანელი
    ├── admin.css       ← ადმინის სტილები
    └── admin.js        ← ადმინის ლოგიკა
```

## 🚀 GitHub-ზე ატვირთვა

1. შექმენით ახალი GitHub repo
2. ატვირთეთ ყველა ფაილი (ლოგო `images/logo.png`-ში)
3. Vercel-ზე: Import the repo → Deploy

## 🔑 ადმინ პანელი

- URL: `yourdomain.com/admin/`
- ნაგულისხმევი პაროლი: `eduspace2024`
- პაროლის შეცვლა შესაძლებელია პარამეტრებში

## ⚙️ ფუნქციონალი

### პოდკასტები
- YouTube ლინკის დამატება
- სათაური + აღწერა
- ავტომატური thumbnail YouTube-დან
- iframe player modal-ში

### სტატიები
- სათაური, ტეგი, excerpt, სრული ტექსტი
- ფოტოს ატვირთვა ლოკალიდან (base64)
- სტატიის გახსნა modal-ში

### პარამეტრები
- ლოგოს ატვირთვა
- Hero ქავერის ატვირთვა
- საიტის სახელი და სლოგანი
- „ჩვენ შესახებ" ტექსტი
- პაროლის შეცვლა

## 📌 მნიშვნელოვანი შენიშვნები

- ყველა მონაცემი ინახება browser-ის **localStorage**-ში
- სხვადასხვა browser ან device-იდან მონაცემები არ გაზიარდება
- მომავალში backend (Firebase/Supabase) შეიძლება დაემატოს
